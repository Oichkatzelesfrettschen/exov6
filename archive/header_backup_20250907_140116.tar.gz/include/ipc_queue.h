#pragma once

struct mailbox;
extern struct mailbox ipcs;
void ipc_timed_init(void);
