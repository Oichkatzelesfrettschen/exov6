#pragma once
#define T_SYSCALL 64
