#pragma once

#ifndef CONFIG_SMP
#define CONFIG_SMP 1
#endif
