#pragma once
#include "../dag.h"

void libos_setup_beatty_dag(void);
