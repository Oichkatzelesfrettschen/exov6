#pragma once

/* STREAMS pipeline helpers used by scheduler callbacks */

void streams_stop(void);
void streams_yield(void);

void streams_sched_init(void);
