#pragma once
#define SIGUSR1 1
